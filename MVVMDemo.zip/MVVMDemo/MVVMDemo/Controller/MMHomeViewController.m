//
//  MMHomeViewController.m
//  MVVMDemo
//
//  Created by Evan on 16/7/5.
//  Copyright © 2016年 Evan. All rights reserved.
//

#import "MMHomeViewController.h"

#import "MMHomeTableViewCell.h"
#import "MMHomeControlHandler.h"
#import "MMHomeDataSource.h"

@interface MMHomeViewController ()<UITableViewDelegate>

@property (nonatomic, weak)  UITableView *tableView;

@property (nonatomic, strong) NSArray *data;

/** 业务逻辑处理 */
@property (nonatomic, strong) MMHomeControlHandler *controlHandler;

/** tableView DataSource */
@property (nonatomic, strong) MMHomeDataSource *dataSource;

@end

@implementation MMHomeViewController

#pragma mark - Control
- (NSArray *)data
{
    if (!_data)
    {
        _data = [NSArray array];
    }
    return _data;
}

- (MMHomeControlHandler *)controlHandler
{
    if (!_controlHandler)
    {
        _controlHandler = [[MMHomeControlHandler alloc] init];
    }
    return _controlHandler;
}

#pragma mark - Control
- (UITableView *)tableView
{
    if (!_tableView)
    {
        UITableView *tableView = [[UITableView alloc] init];
        
        tableView.frame = self.view.bounds;
        [tableView registerClass:[MMHomeTableViewCell class] forCellReuseIdentifier:MMHomeTableViewCellID];
        
        self.tableView = tableView;
        [self.view addSubview:tableView];
    }
    return _tableView;
}

#pragma mark - LfileCycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self setupNavigation];
    self.tableView.delegate = self;
    [self loadNetworking];
    [self setupTableViewDataSource];
}

#pragma mark - Public Method
- (void)loadNetworking
{
    __weak typeof(self) weakSelf = self;
    [self.controlHandler requestModels:^(NSArray *arrayModels) {
        
        weakSelf.data = arrayModels;
        [weakSelf.tableView reloadData];
    } failed:^(NSDictionary *userInfo) {
        
    }];
}

#pragma mark - Layout
- (void)setupNavigation
{
    self.title = @"首页";
}

#pragma mark - UItableView DataSource
- (void)setupTableViewDataSource
{
    _dataSource = [[MMHomeDataSource alloc] initWithDatas:self.data];
    
    self.tableView.dataSource = _dataSource;
}

@end
