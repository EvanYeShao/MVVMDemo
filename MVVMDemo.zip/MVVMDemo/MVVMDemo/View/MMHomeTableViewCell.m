//
//  MMHomeTableViewCell.m
//  MVVMDemo
//
//  Created by Evan on 16/7/5.
//  Copyright © 2016年 Evan. All rights reserved.
//

#import "MMHomeTableViewCell.h"
#import "MMHomeViewModel.h"
#import "MMHomeModel.h"

static CGFloat const TITLE_LABEL_LEFT = 10.f;

@interface MMHomeTableViewCell ()

@property (nonatomic, weak) UILabel *titleLable;

@end

@implementation MMHomeTableViewCell

#pragma mark - Data
- (void)setModel:(MMHomeViewModel *)model
{
    _model = model;
    self.titleLable.text = model.model.title;
}

#pragma mark - Control
- (UILabel *)titleLable
{
    if (!_titleLable)
    {
        UILabel *titleLable = [[UILabel alloc] init];
        
        self.titleLable = titleLable;
        [self.contentView addSubview:titleLable];
    }
    return _titleLable;
}

#pragma mark - Initalize
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        [self setupContenConstraints];
    }
    return self;
}

#pragma mark - Layout
- (void)setupContenConstraints
{
    __weak typeof(self) weakSelf = self;
    [self.titleLable mas_makeConstraints:^(MASConstraintMaker *make) {
       
        make.centerY.equalTo(weakSelf.contentView.mas_centerY);
        make.left.equalTo(weakSelf.contentView.mas_left).offset(TITLE_LABEL_LEFT);
    }];
}

@end
