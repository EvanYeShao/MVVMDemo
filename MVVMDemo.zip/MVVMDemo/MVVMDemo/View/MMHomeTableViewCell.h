//
//  MMHomeTableViewCell.h
//  MVVMDemo
//
//  Created by Evan on 16/7/5.
//  Copyright © 2016年 Evan. All rights reserved.
//

#import <UIKit/UIKit.h>

static NSString * const MMHomeTableViewCellID = @"MMHomeTableViewCellID";

@class MMHomeViewModel;

@interface MMHomeTableViewCell : UITableViewCell

@property (nonatomic, strong) MMHomeViewModel *model;

@end
