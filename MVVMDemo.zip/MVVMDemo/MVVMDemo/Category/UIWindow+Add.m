//
//  UIWindow+Add.m
//  MVVMDemo
//
//  Created by Evan on 16/7/5.
//  Copyright © 2016年 Evan. All rights reserved.
//

#import "UIWindow+Add.h"
#import "MMHomeViewController.h"

@implementation UIWindow (Add)

+ (UIWindow *)screenBounsWithWidow
{
    return [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
}

- (void)switchRootViewController
{
    self.backgroundColor = [UIColor whiteColor];
    UINavigationController *navgationController = [[UINavigationController alloc] initWithRootViewController:[[MMHomeViewController alloc] init]];
    self.window.rootViewController = navgationController;
    [self setRootViewController:navgationController];
}

@end
