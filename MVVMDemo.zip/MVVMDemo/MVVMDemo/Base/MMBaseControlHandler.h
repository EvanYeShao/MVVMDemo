//
//  MMBaseControlHandler.h
//  MVVMDemo
//
//  Created by Evan on 16/7/5.
//  Copyright © 2016年 Evan. All rights reserved.
//  业务逻辑处理基类

#import <Foundation/Foundation.h>

typedef void(^ControlSuccessHandle)(id obj);  // 成功处理
typedef void(^ControlFailureHandle)(id obj);  // 失败处理
typedef void(^ControlAllCompletiondHandle)(); // 所有完成处理

@interface MMBaseControlHandler : NSObject

@end
