//
//  MMHomeControlHandler.h
//  MVVMDemo
//
//  Created by Evan on 16/7/5.
//  Copyright © 2016年 Evan. All rights reserved.
//  业务逻辑处理

#import "MMBaseControlHandler.h"

@interface MMHomeControlHandler : MMBaseControlHandler

-(void)requestModels:(ControlSuccessHandle)successBlock
                 failed:(ControlFailureHandle)failedBlock;

@end
