//
//  MMHomeControlHandler.m
//  MVVMDemo
//
//  Created by Evan on 16/7/5.
//  Copyright © 2016年 Evan. All rights reserved.
//

#import "MMHomeControlHandler.h"
#import "MMHomeViewModel.h"
#import "MMHomeModel.h"

@interface MMHomeControlHandler ()

@property(nonatomic,strong) NSMutableArray* sourceModels;

@end

@implementation MMHomeControlHandler

#pragma mark - Data
- (NSMutableArray *)sourceModels
{
    if (!_sourceModels)
    {
        _sourceModels = [NSMutableArray array];
    }
    return _sourceModels;
}

#pragma mark - Initalize
- (instancetype)init
{
    self = [super init];
    if (self)
    {
        
    }
    return self;
}

-(void)requestModels:(ControlSuccessHandle)successBlock
              failed:(ControlFailureHandle)failedBlock
{
    // 模仿网络操作
    NSArray *array = @[@"MVC",@"MVVM",@"KVC",@"KVO",
                       @"SingleCase",@"Block",
                       @"Delegate",@"Notice"];
    
    NSMutableArray *tempArray = [NSMutableArray array];
    for (int i = 0; i < array.count; ++i)
    {
        NSString *title = array[i];
        MMHomeModel *model = [[MMHomeModel alloc] initWithModel:title];
        MMHomeViewModel *viewModel = [[MMHomeViewModel alloc] initWithMMModel:model];
        [tempArray addObject:viewModel];
    }
    self.sourceModels = tempArray;
    successBlock(self.sourceModels);
}

@end
