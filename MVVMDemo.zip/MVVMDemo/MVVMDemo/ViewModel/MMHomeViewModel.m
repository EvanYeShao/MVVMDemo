//
//  MMHomeViewModel.m
//  MVVMDemo
//
//  Created by Evan on 16/7/5.
//  Copyright © 2016年 Evan. All rights reserved.
//

#import "MMHomeViewModel.h"

@implementation MMHomeViewModel

- (instancetype)initWithMMModel:(MMHomeModel *)model
{
    self = [super init];
    if (self)
    {
        self.model = model;
    }
    return self;
}

@end
