//
//  MMHomeViewModel.h
//  MVVMDemo
//
//  Created by Evan on 16/7/5.
//  Copyright © 2016年 Evan. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MMHomeModel;

@interface MMHomeViewModel : NSObject

- (instancetype)initWithMMModel:(MMHomeModel *)model;

@property (nonatomic, strong) MMHomeModel *model;

@end
