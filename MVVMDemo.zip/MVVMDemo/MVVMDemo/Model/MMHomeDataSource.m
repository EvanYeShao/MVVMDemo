//
//  MMHomeDataSource.m
//  MVVMDemo
//
//  Created by Evan on 16/7/5.
//  Copyright © 2016年 Evan. All rights reserved.
//

#import "MMHomeDataSource.h"
#import "MMHomeTableViewCell.h"

@interface MMHomeDataSource ()

@property (nonatomic, strong) NSArray *datas;

@end

@implementation MMHomeDataSource

#pragma mark - Data
- (NSArray *)datas
{
    if (!_datas)
    {
        _datas = [NSArray array];
    }
    return _datas;
}

#pragma mark - Initalize
-(instancetype)initWithDatas:(NSArray *)datas
{
    self = [super init];
    if (self)
    {
        self.datas = datas;
    }
    return self;
}

#pragma mark - UItableView Delegate && DataSoure
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.datas.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MMHomeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:MMHomeTableViewCellID forIndexPath:indexPath];
    
    cell.model = self.datas[indexPath.row];
    return cell;
}

@end
