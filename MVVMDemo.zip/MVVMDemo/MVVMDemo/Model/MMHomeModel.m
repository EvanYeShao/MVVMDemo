//
//  MMHomeModel.m
//  MVVMDemo
//
//  Created by Evan on 16/7/5.
//  Copyright © 2016年 Evan. All rights reserved.
//

#import "MMHomeModel.h"

@implementation MMHomeModel

- (instancetype)initWithModel:(NSString *)title
{
    self = [super init];
    if (self)
    {
        self.title = title;
    }
    return self;
}

@end
