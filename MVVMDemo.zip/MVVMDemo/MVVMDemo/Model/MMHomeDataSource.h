//
//  MMHomeDataSource.h
//  MVVMDemo
//
//  Created by Evan on 16/7/5.
//  Copyright © 2016年 Evan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MMHomeDataSource : NSObject<UITableViewDataSource>

-(instancetype)initWithDatas:(NSArray *)datas;

@end
